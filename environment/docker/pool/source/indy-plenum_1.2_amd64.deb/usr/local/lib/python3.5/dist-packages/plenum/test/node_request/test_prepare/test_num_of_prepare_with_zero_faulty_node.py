nodeCount = 7


def testNumOfPrepareWithZeroFaultyNode(prepared1):
    pass
