class NotFullyConnected(Exception):
    pass


class TestException(Exception):
    pass
