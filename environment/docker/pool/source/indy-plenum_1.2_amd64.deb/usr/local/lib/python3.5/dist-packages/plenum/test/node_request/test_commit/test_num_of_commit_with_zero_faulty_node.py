nodeCount = 7


def testNumOfCommitWithZeroFaultyNode(committed1):
    pass
