

def expectedAgentConnected():
    return 10


def expectedAgentPing():
    return 5


def expectedClaimsReceived():
    return 20


def expectedTranscriptWritten():
    return 10


def expectedJobCertWritten():
    return 10


def expected_accept_request():
    return 10
