from common.serializers.json_serializer import JsonSerializer

attrib_raw_data_serializer = JsonSerializer()
