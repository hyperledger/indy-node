NODE_REQUEST_COMPLETED = "Node request completed"
NODE_REQUEST_FAILED = "Node request failed"
SCHEMA_ADDED = [
    'The following schema is published to the Indy distributed ledger',
    'Sequence number is']
SCHEMA_NOT_ADDED_DUPLICATE = [
    'can have one and only one SCHEMA with name']
CLAIM_DEF_ADDED = [
    'The claim definition was published to the Indy distributed ledger',
    'Sequence number is']
INVALID_SYNTAX = "Invalid syntax"
ERROR = 'Error:'
