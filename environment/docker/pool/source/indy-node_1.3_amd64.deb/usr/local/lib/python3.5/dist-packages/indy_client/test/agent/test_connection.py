import pytest


@pytest.mark.skip("SOV-564. Not yet implemented")
def test_connect():
    """
    Connect to the indy network and ensure we have the latest keys for all of
    the owner's identifiers.
    """
    raise NotImplementedError
