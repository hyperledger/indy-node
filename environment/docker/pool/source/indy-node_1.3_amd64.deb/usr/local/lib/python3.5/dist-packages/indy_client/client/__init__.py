ISSUER = "issuer"
PROVER = "prover"
VERIFIER = "verifier"
roles = [ISSUER, PROVER, VERIFIER]
