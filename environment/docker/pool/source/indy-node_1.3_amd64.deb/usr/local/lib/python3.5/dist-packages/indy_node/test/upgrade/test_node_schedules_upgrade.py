def test_node_schedules_upgrade(upgradeScheduled):
    pass
